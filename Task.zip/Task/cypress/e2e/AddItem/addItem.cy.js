/// <reference types="Cypress" />
import { Util } from '../../utils/utils';
import { HomeSelectors } from '../../pages/HomePage/homePageSelectors';

const util = new Util();
const homeSelecter = new HomeSelectors();
const loginCredentials = require('../../envTestData/loginTestData/loginData.json');
const data = require('./data.json');

describe('Add Item to car', () => {
  before(' Login to portal', () => {
    Cypress.on('uncaught:exception', () => false);
    util.openPortal();
    util.login(loginCredentials.UserName, loginCredentials.Password);
  });

  it('Add item to car then logout', () => {
    Cypress.on('uncaught:exception', () => false);
    util.clearItems();
    homeSelecter.addItem().click();
    homeSelecter.containerCar().click();
    expect(homeSelecter.itemTitle().should('contain', data.itemOneName));
    util.logout();
  });
});
