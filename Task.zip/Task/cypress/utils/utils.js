/// <reference types="Cypress" />
import { LoginSelectors } from '../pages/NewLogin/losginSelectors';
import { HomeSelectors } from '../pages/HomePage/homePageSelectors';

const loginSelectors = new LoginSelectors();
const homeSelectors = new HomeSelectors();
export class Util {
  openPortal() {
    cy.visit('/');
  }

  login(username, password) {
    loginSelectors.userName().type(username);
    loginSelectors.password().type(password);
    loginSelectors.loginButton().click();
    loginSelectors.appLogo().should('be.visible');
  }

  logout() {
    homeSelectors.menu().click();
    homeSelectors.logoutButton().click();
    expect(loginSelectors.loginButton().should('be.visible'));
  }

  clearItems() {
    homeSelectors.menu().click();
    homeSelectors.resetAppStore().click();
    cy.reload();
  }
}
export default Util;
