export class HomeSelectors {
  containerCar() {
    return cy.get('div[id="shopping_cart_container"]');
  }

  addItem() {
    return cy.get('button[id="add-to-cart-sauce-labs-backpack"]');
  }

  itemTitle() {
    return cy.get('div[class="inventory_item_name"]').first();
  }

  resetAppStore() {
    return cy.get('a[id="reset_sidebar_link"]');
  }

  logoutButton() {
    return cy.get('a[id="logout_sidebar_link"]');
  }

  menu() {
    return cy.get('button[id="react-burger-menu-btn"]');
  }
}
export default HomeSelectors;
