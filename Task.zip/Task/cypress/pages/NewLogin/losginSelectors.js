export class LoginSelectors {
  userName() {
    return cy.get('input[id="user-name"]');
  }

  password() {
    return cy.get('input[id="password"]');
  }

  loginButton() {
    return cy.get('input[id="login-button"]');
  }

  appLogo() {
    return cy.get('div[class="app_logo"]');
  }
}
export default LoginSelectors;
