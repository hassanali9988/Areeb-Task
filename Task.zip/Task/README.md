### Areeb Task
Add Item to card Scenario

### To run Prject 
## Clone project 
git clone link
open project in visual stadio code 
open the terminal for visual stadio code 
##Installation
npm init
npm i
node -v
npm -v
npm install cypress --save dev
npm install --save dev eslint

1- Run tests on GUL useing:
```
npx cypress testing

2- Run tests headless:
npm run AddItem

